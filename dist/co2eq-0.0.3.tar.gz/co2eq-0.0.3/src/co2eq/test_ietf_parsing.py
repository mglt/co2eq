from ietf_meeting import IETFMeeting
from os.path import isfile

for ietf_name in [ 'IETF108', 'IETF109', 'IETF110', 'IETF111', 'IETF112', 'IETF113', 'IETF114' ]:
  print( "---- {ietf_name}" )
  ietf = IETFMeeting( ietf_name, base_output_dir='/tmp/' )
  if isfile( ietf.attendee_list_html ) is False:
    print( "   --> htm" )
    ietf.get_attendee_list_html()
  print( " --> parsing htm" )
  json_attendees = ietf.parse_htm_108( ) 
  print( json_attendees[:20] ) 

  
