## Installation 

1) install the climate neutral 

```
sudo python3 install setup.py
```

TO DO:
* git pull new version of climate_neutral
* produce a package.
